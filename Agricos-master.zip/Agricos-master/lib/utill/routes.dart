class MyRoutes {

  static String triggerpage = "/trigger";
  static String loginscreen = "/loginscreen";
  static String signupscreen = "/signupscreen";
  static String farmingcreen = "/farmingdetails";
  static String authentication = "/authenticationscreen";
  static String done = "/done";



}


